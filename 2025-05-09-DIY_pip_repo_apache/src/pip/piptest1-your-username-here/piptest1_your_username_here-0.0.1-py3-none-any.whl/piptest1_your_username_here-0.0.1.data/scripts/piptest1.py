#!python

print("Hello.")
